// Inisialisasi AOS animation
AOS.init({
  duration: 800,
  once: true
});
